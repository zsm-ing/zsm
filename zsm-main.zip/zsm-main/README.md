//sing-box//
## 脚本：
```
bash <(curl -sL https://gh-proxy.com/https://raw.githubusercontent.com/zming66/zsm/refs/heads/main/sbshall.sh)
```
